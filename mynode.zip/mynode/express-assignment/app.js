var express = require("express");
var app = express();

app.get("/",function(req,res){
    res.send("Hi There, welcome to my assignment");
});

app.get("/speak/:animal",function(req,res){
    var animal = req.params.animal;
    var lang = {
        dog:"woof woof!",
        cat:"i hate you human",
        cow:"Moo",
        pig:"Oink",
        goldfish:"..."
    };
    res.send("The "+animal+" says '"+lang[animal]+"'");
})

app.get("/repeat/:string/:count",function(req,res){
    var str = req.params.string;
    var count = req.params.count;
    var fstr=""
    for(i=0;i<count;i++){
        fstr = fstr+" "+str;
    }
    res.send(fstr)
})


app.get("*",function(req,res){
    res.send("Sorry, page not found...");
});

app.listen(3000,function(){
    console.log("Server started at 3000");
})
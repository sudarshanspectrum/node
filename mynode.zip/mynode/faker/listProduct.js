var fk = require('faker');
console.log("================= \n Welcome to Shop \n=================");
for(i=0;i<10;i++){
	console.log(fk.commerce.productName() + " - " + fk.commerce.price());
}
console.log("\n");

//console.log(fk.helpers.createCard());

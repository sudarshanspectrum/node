var express = require("express");
var app = express();



app.get("/",function(req,res){
    res.send("Hello M.")
    console.log(req);
})
app.get("/good",function(req,res){
    res.send("Good");
})

app.get("/r/:s",function(req,res){
    res.send(req.params.s);
    console.log(req)
})

app.get("*",function(req,res){
    res.send("Anything");
})

app.listen(3000,function(){
    console.log("Listening at port 3000");
})

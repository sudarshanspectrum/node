var app = require("express")();

app.get("/",function(req,res){
    res.send("Welcome to Homepage !!");
})

app.listen(3000,function(){
    console.log("Server sarted and listenig at 3000");
})